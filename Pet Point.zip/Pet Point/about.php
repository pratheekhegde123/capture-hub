<?php
include 'header.php';
?>

    <!-- Start All Title Box -->
    <div class="all-title-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>ABOUT US</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active">ABOUT US</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End All Title Box -->

    <!-- Start About Page  -->
    <div class="about-box-main">
        <div class="container">
            <div class="row">
				<div class="col-lg-6">
                    <div class="banner-frame"> <img class="img-fluid" src="images/about-img.jpg" alt="" />
                    </div>
                </div>
                <div class="col-lg-6">
                    <h2 class="noo-sh-title-top">We are <span>Pet Point</span></h2>
                    <p>Over a period of 25 years, Pet point has gone from strength to strength and has become a Rs. 9000+ crore company that makes it India’s Top E-commerce platform. Along the way, petpoint's pioneering efforts helped create thousands of rural entrepreneurs who share the growth successfully. petpoint ranks among the top ten Ecommerce companies worldwide. With operations in all the states across India, it offers a range of pet products</p>
                    <p><h4>Recognitions</h4>
                        <p>Awarded 'Pet eRetailer of the Year 2013' – <a>Indian eRetail Awards</a></p>
<p>Awarded 'Best E-commerce Website for 2012' by IAMAI – <a>India Digital Awards</a></p>
<p>Awarded 'Images Most Admired Retailer of the Year: Non–Store Retail' for 2012 by <a>Images Group</a></p>
<p>Awarded 'Best E-commerce Partner of the year 2011-12' by <a>SOP India</a></p></p>
					<a class="btn hvr-hover" href="">Know More</a>
                </div>
            </div>
            <div class="row my-5">
                <div class="col-sm-6 col-lg-4">
                    <div class="service-block-inner">
                        <h3>24X7 Live Support</h3>
                        <p>Contact us anytime. We are available 24x7 + 365 days. Dedicated support will be given. </p>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="service-block-inner">
                        <h3>We are Expert</h3>
                        <p>We strive to have a positive impact on customers, employees, small businesses, the economy, and communities. Petpoint team members are smart, passionate builders with different backgrounds and goals, who share a common desire to always be learning and inventing on behalf of our customers. </p>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="service-block-inner">
                        <h3>We are Trusted</h3>
                        <p>All the Shops and Products are 100% verified with our representatives.. </p>
                    </div>
                </div>
            </div>

      
        </div>
    </div>
    <!-- End About Page -->



<?php
include 'ourpartners.php';
include 'footer.php';
?>